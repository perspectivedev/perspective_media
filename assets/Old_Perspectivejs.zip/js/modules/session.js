class SessionEvent extends Event {
    static LOGIN = 'session.login';
    static LOGOUT = 'session.logout';

    constructor(name, data) {
        super(name);
        this.data = data;
    }

    static newLogin(data) {
        return new SessionEvent(SessionEvent.LOGIN, data);
    }

    static newLogout(data) {
        return new SessionEvent(SessionEvent.LOGOUT, data);
    }
}

class Session extends EventTarget {
    static STORAGE_KEY = 'session';

    constructor() {
        super();
        this._loggedIn = false;
        this._user = null;
    }

    isLoggedIn() {
        return this._loggedIn;
    }

    getUser() {
        return this._user;
    }

    /**
     * 
     * This basically sets the login state of the current user.
     * 
     * @param {object} user data of who is logged in 
     * @returns true if login successful, false if already loggedIn
     */
    fireLogin(user) {
        if (this._loggedIn) {
            return false;
        }
        this._user = user;
        this._loggedIn = true;
        this.setLocalStorage(true, user);
        super.dispatchEvent(SessionEvent.newLogin({
            user: user
        }));
        return true;
    }

    /**
     * 
     * This handles logging out..
     * 
     * @returns true if logged out, false is not logged in
     */
    fireLogout() {
        if (!this._loggedIn) {
            return false;
        }
        let temp = this._user;
        this._loggedIn = false;
        this._user = null;
        this.setLocalStorage(false);
        super.dispatchEvent(SessionEvent.newLogout({
            user: temp
        }));
        return true;
    }

    /**
     * This is an internal Function you won't be calling it yourself.
     * 
     */
    loadLocalStorage() {
        const stored = localStorage.getItem(Session.STORAGE_KEY);
        if (stored !== null) {
            const userData = JSON.parse(stored);
            this._loggedIn = userData.loggedIn;
            this._user = userData.user;
        }
    }

    /*
    This is also a internal function
    */
    setLocalStorage(loggedIn, userId) {
        if (loggedIn) {
            localStorage.setItem(Session.STORAGE_KEY, JSON.stringify({
                loggedIn: loggedIn,
                user: userId
            }));
        } else {
            localStorage.removeItem(Session.STORAGE_KEY);
        }
    }
}

const session = new Session();
session.loadLocalStorage();
exports.session = session;
exports.SessionEvent = SessionEvent;


/*
    Using this class is basically

    const {
        session
    } = require('assets/js/modules/session.js');


    //to login
    session.fireLogin(USER_DATA_HERE); //UserData can be an object or an id or whatever you want.

    //to log out
    session.fireLogout();

    //to check if user is logged in or really (Session is valid)
    const boolState = session.isLoggedIn(); //This is true or false if there is a session
    //If you want a session fireLogin
    //Basically if you look at somewhere there is a function called updateUserState(); 
    //Which handles the setting and unsetting of the login button text.




*/