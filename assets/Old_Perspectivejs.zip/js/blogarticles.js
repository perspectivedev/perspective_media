const articleTitle = document.getElementById('article-title');
const articleDate = document.getElementById('article-date');
const articleTime = document.getElementById('article-time');
const 
const postArticle = document.getElementById('article-content');
const 















/***
 *                     <article class="blog-post">
 *                          <-- start of blog article -->
 * 
                            <header class="blog-header">
                                <h1 class="article-title">Hello World</h1>
                                <h2 class="article-date"></h2>
                                <h2 class="article-time"></h2>
                            </header>

                        <div class="article-section">
                            <img src="assets/images/perspective_blog_img.jpg" class="blogImg"
                                alt="perspective_blog_img" />
                            <p class="article-content" data-pubdate="date"></p>
                        </div>

                        <-- end of blog article -->

                        <!-- start of comment section -->
                        <div class="comment-section">
                            <article class="comments" data-done=false>
                                <div class="post-comment" id="id"></div>
                            </article>
                        </div>
                        <!-- end of comment section -->
                    </article>
                </div>
                <!-- end of article section -->

                <!-- start of author form section -->
                <div class="author-form-section">
                    <form class="author-form">
                        <div class="input-section">
                            <div class="name-input"><input type="text" class="author-name" name="article"
                                    placeholder="Name" id="autherName" />
                                <p id="user-name-err" class="input-warning"></p>
                            </div>
                            <div class="email-input"><input type="text" class="author-email" name="article"
                                    placeholder="Email" id="authorEmail" />
                                <p id="user-email-err" class="input-warning"></p>
                            </div>
                            <div class="img-input"><input type="" class="author-img" name="article" placeholder="url()"
                                    id="userImg" />
                                <p id="user-img-err" class="input-warning"></p>
                            </div>
                            <div class="author-textarea"><textarea name="article" class="author-article" rows="5"
                                    placeholder="Article" id="blog"></textarea>
                            </div>
                        </div>
                        <div class="submit-blog"><button class="add-atricle" type="submit" value="Add-Article">Add
                                Article</button></div>
                    </form>
                </div>
 * 
 * 
 * 
 * 
 * 
 * 
 */